import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

// Class representing a Book record
class Book {
    private final String id;
    private final String title;
    private final String author;
    private final String category;
    private boolean isIssued;
    private String issuedToMemberId;

    public Book(String id, String title, String author, String category) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.isIssued = false;
        this.issuedToMemberId = "";
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public boolean isIssued() { return isIssued; }
    
    public void issueBook(String memberId) {
        this.isIssued = true;
        this.issuedToMemberId = memberId;
    }

    public void returnBook() {
        this.isIssued = false;
        this.issuedToMemberId = "";
    }

    @Override
    public String toString() {
        String status = isIssued ? "Issued to [" + issuedToMemberId + "]" : "Available";
        return String.format("ID: %-5s | Title: %-25s | Author: %-15s | Category: %-12s | Status: %s", 
                id, title, author, category, status);
    }
}

// Class representing a Member record
class Member {
    private final String memberId;
    private final String name;
    private double fine;

    public Member(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.fine = 0.0;
    }

    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public double getFine() { return fine; }
    public void addFine(double amount) { this.fine += amount; }
    public void payFine() { this.fine = 0.0; }

    @Override
    public String toString() {
        return String.format("Member ID: %-8s | Name: %-15s | Pending Fine: $%.2f", memberId, name, fine);
    }
}

// Main Library Management Class
public class LibraryManagementSystem {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, Book> booksDatabase = new HashMap<>();
    private static final Map<String, Member> membersDatabase = new HashMap<>();

    public static void main(String[] args) {
        // Seeding initial dummy records (Book-keeping)
        booksDatabase.put("101", new Book("101", "Effective Java", "Joshua Bloch", "Programming"));
        booksDatabase.put("102", new Book("102", "Introduction to Algos", "Cormen", "Algorithms"));
        booksDatabase.put("103", new Book("103", "Clean Code", "Robert Martin", "Programming"));
        booksDatabase.put("104", new Book("104", "The Hobbit", "J.R.R. Tolkien", "Fiction"));

        membersDatabase.put("M001", new Member("M001", "Lacxmi Gupta"));
        membersDatabase.put("M002", new Member("M002", "Amit Sharma"));

        System.out.println("=================================================");
        System.out.println("   WELCOME TO DIGITAL LIBRARY MANAGEMENT SYSTEM  ");
        System.out.println("=================================================");

        while (true) {
            System.out.println("\n--- LOGIN AS ---");
            System.out.println("1. Admin Module");
            System.out.println("2. User/Member Module");
            System.out.println("3. Exit System");
            System.out.print("Choose portal (1-3): ");

            String portalChoice = scanner.nextLine();
            switch (portalChoice) {
                case "1":
                    handleAdminPortal();
                    break;
                case "2":
                    handleUserPortal();
                    break;
                case "3":
                    System.out.println("\nShutting down Library Server. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // ==================== ADMIN PORTAL MODULE ====================
    private static void handleAdminPortal() {
        System.out.print("\nEnter Admin Password: ");
        String pass = scanner.nextLine();
        if (!pass.equals("adminpass")) {
            System.out.println("❌ Access Denied! Wrong Password.");
            return;
        }

        while (true) {
            System.out.println("\n--- ADMIN DASHBOARD ---");
            System.out.println("1. Add New Book Entry");
            System.out.println("2. Modify/Delete Book Entry");
            System.out.println("3. Register New Member");
            System.out.println("4. Generate Library Report");
            System.out.println("5. Back to Main Login");
            System.out.print("Select Operation (1-5): ");

            String choice = scanner.nextLine();
            if (choice.equals("5")) break;

            switch (choice) {
                case "1":
                    System.out.print("Enter Book ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter Category: ");
                    String category = scanner.nextLine();
                    booksDatabase.put(id, new Book(id, title, author, category));
                    System.out.println("✔ Book record added successfully!");
                    break;

                case "2":
                    System.out.print("Enter Book ID to Modify/Delete: ");
                    String modId = scanner.nextLine();
                    if (booksDatabase.containsKey(modId)) {
                        System.out.print("Type 'DELETE' to remove, or 'MODIFY' to update category: ");
                        String op = scanner.nextLine().toUpperCase();
                        if (op.equals("DELETE")) {
                            booksDatabase.remove(modId);
                            System.out.println("✔ Book record removed.");
                        } else if (op.equals("MODIFY")) {
                            System.out.print("Enter New Category: ");
                            String newCat = scanner.nextLine();
                            Book old = booksDatabase.get(modId);
                            booksDatabase.put(modId, new Book(old.getId(), old.getTitle(), "Unknown", newCat));
                            System.out.println("✔ Book record modified.");
                        }
                    } else {
                        System.out.println("❌ Book ID not found.");
                    }
                    break;

                case "3":
                    System.out.print("Enter New Member ID: ");
                    String mId = scanner.nextLine();
                    System.out.print("Enter Member Full Name: ");
                    String mName = scanner.nextLine();
                    membersDatabase.put(mId, new Member(mId, mName));
                    System.out.println("✔ Member registered successfully!");
                    break;

                case "4":
                    generateReport();
                    break;

                default:
                    System.out.println("Invalid selection.");
            }
        }
    }

    // ==================== USER/MEMBER PORTAL MODULE ====================
    private static void handleUserPortal() {
        System.out.print("\nEnter your Member ID (e.g., M001): ");
        String memberId = scanner.nextLine();
        if (!membersDatabase.containsKey(memberId)) {
            System.out.println("❌ Invalid Member ID! Access restricted.");
            return;
        }

        Member member = membersDatabase.get(memberId);
        while (true) {
            System.out.println("\n--- USER CONSOLE (" + member.getName() + ") ---");
            System.out.println("1. Browse All Books & Categories");
            System.out.println("2. Search Book by Category");
            System.out.println("3. Issue/Borrow a Book");
            System.out.println("4. Return a Book & Fine Check");
            System.out.println("5. Submit Query via Email (Simulated)");
            System.out.println("6. Logout");
            System.out.print("Select Operation (1-6): ");

            String choice = scanner.nextLine();
            if (choice.equals("6")) break;

            switch (choice) {
                case "1":
                    System.out.println("\n--- LIBRARY BOOKS CATALOGUE ---");
                    for (Book b : booksDatabase.values()) {
                        System.out.println(b);
                    }
                    break;

                case "2":
                    System.out.print("Enter Category to search: ");
                    String searchCat = scanner.nextLine().toLowerCase();
                    System.out.println("\n--- SEARCH RESULTS ---");
                    for (Book b : booksDatabase.values()) {
                        if (b.getCategory().toLowerCase().contains(searchCat)) {
                            System.out.println(b);
                        }
                    }
                    break;

                case "3":
                    System.out.print("Enter Book ID you want to issue: ");
                    String bId = scanner.nextLine();
                    Book targetBook = booksDatabase.get(bId);
                    if (targetBook != null && !targetBook.isIssued()) {
                        targetBook.issueBook(memberId);
                        System.out.println("✔ Book '" + targetBook.getTitle() + "' has been successfully issued to you.");
                    } else {
                        System.out.println("❌ Book is either unavailable or already issued.");
                    }
                    break;

                case "4":
                    System.out.print("Enter Book ID you want to return: ");
                    String retId = scanner.nextLine();
                    Book retBook = booksDatabase.get(retId);
                    if (retBook != null && retBook.isIssued()) {
                        retBook.returnBook();
                        // Simulating a minor fine generation structure for demonstration
                        System.out.print("Enter days late (0 if on time): ");
                        int days = Integer.parseInt(scanner.nextLine());
                        if (days > 0) {
                            double generatedFine = days * 2.0; // $2 per day
                            member.addFine(generatedFine);
                            System.out.printf("⚠️ Late return! Fine generated: $%.2f. Current pending: $%.2f\n", generatedFine, member.getFine());
                        } else {
                            System.out.println("✔ Book returned on time. Thank you!");
                        }
                    } else {
                        System.out.println("❌ Invalid operation or book was not issued.");
                    }
                    break;

                case "5":
                    System.out.print("Type your query statement: ");
                    String query = scanner.nextLine();
                    System.out.println("📧 Simulating Email Thread: Sending query to support@library.digital.org...");
                    System.out.println("✔ Email Dispatched! Admin will reply shortly.");
                    break;

                default:
                    System.out.println("Invalid selection.");
            }
        }
    }

    // Central report generation system
    private static void generateReport() {
        System.out.println("\n=================================================");
        System.out.println("            CENTRAL SYSTEM MANAGEMENT REPORT      ");
        System.out.println("=================================================");
        System.out.println("TOTAL BOOKS CLASSIFIED: " + booksDatabase.size());
        System.out.println("REGISTERED MEMBERS    : " + membersDatabase.size());
        System.out.println("\n--- Current Member Statistics ---");
        for (Member m : membersDatabase.values()) {
            System.out.println(m);
        }
        System.out.println("=================================================");
    }
}