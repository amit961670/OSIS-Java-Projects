import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

// Class to represent a Question
class Question {
    String questionText;
    String[] options;
    int correctAnswerIndex; // 1-based index (1 to 4)

    public Question(String questionText, String[] options, int correctAnswerIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
    }
}

// Class to manage User Session & Profile
class UserProfile {
    String userId;
    String password;
    String fullName;

    public UserProfile(String userId, String password, String fullName) {
        this.userId = userId;
        this.password = password;
        this.fullName = fullName;
    }
}

public class OnlineExamSystem {
    private static final Scanner scanner = new Scanner(System.in);
    private static UserProfile currentUser = new UserProfile("student123", "pass123", "Lacxmi Gupta");
    
    private static List<Question> questions = new ArrayList<>();
    private static int[] userAnswers;
    private static boolean isExamSubmitted = false;
    private static Timer examTimer;

    public static void main(String[] args) {
        // Mocking some questions for the exam
        questions.add(new Question("Which component is used to compile, debug and execute the Java programs?", 
                new String[]{"1. JRE", "2. JIT", "3. JDK", "4. JVM"}, 3));
        questions.add(new Question("Which data structure uses LIFO (Last In First Out) property?", 
                new String[]{"1. Queue", "2. Stack", "3. Linked List", "4. Array"}, 2));
        questions.add(new Question("What is the extension of java code files?", 
                new String[]{"1. .txt", "2. .class", "3. .java", "4. .js"}, 3));

        userAnswers = new int[questions.size()];

        System.out.println("=========================================");
        System.out.println("   WELCOME TO ONLINE EXAMINATION SYSTEM  ");
        System.out.println("=========================================");
        
        // FUNCTIONALITY 1: LOGIN
        if (login()) {
            showMainMenu();
        } else {
            System.out.println("❌ Authentication failed. Exiting application.");
        }
    }

    private static boolean login() {
        System.out.println("\n--- LOGIN PORTAL ---");
        System.out.print("Enter User ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Password: ");
        String pass = scanner.nextLine();

        return id.equals(currentUser.userId) && pass.equals(currentUser.password);
    }

    private static void showMainMenu() {
        while (true) {
            System.out.println("\n---------- MAIN MENU ----------");
            System.out.println("Welcome, " + currentUser.fullName);
            System.out.println("1. Update Profile and Password");
            System.out.println("2. Start Online Examination (Timed MCQ)");
            System.out.println("3. Logout & Close Session");
            System.out.print("Choose an option (1-3): ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    // FUNCTIONALITY 2: UPDATE PROFILE AND PASSWORD
                    updateProfile();
                    break;
                case "2":
                    // FUNCTIONALITY 3 & 4: START EXAM (MCQ + TIMER)
                    startExam();
                    return; // Exit system after exam submission
                case "3":
                    // FUNCTIONALITY 5: CLOSING SESSION AND LOGOUT
                    logout();
                    return;
                default:
                    System.out.println("Invalid selection. Try again.");
            }
        }
    }

    private static void updateProfile() {
        System.out.println("\n--- UPDATE PROFILE & PASSWORD ---");
        System.out.print("Enter New Full Name (Current: " + currentUser.fullName + "): ");
        String newName = scanner.nextLine();
        if (!newName.trim().isEmpty()) {
            currentUser.fullName = newName;
        }

        System.out.print("Enter Current Password to authorize change: ");
        String oldPass = scanner.nextLine();

        if (oldPass.equals(currentUser.password)) {
            System.out.print("Enter New Password: ");
            String newPass = scanner.nextLine();
            if (!newPass.trim().isEmpty()) {
                currentUser.password = newPass;
                System.out.println("✔ Profile and Password updated successfully!");
            } else {
                System.out.println("❌ Password cannot be empty.");
            }
        } else {
            System.out.println("❌ Incorrect password! Profile changes discarded.");
        }
    }

    private static void startExam() {
        isExamSubmitted = false;
        int examDurationSeconds = 45; // Test duration set to 45 seconds for quick demo
        
        System.out.println("\n=========================================");
        System.out.println("              EXAM STARTED               ");
        System.out.println("=========================================");
        System.out.println("Total Questions: " + questions.size());
        System.out.println("Time Limit: " + examDurationSeconds + " seconds.");
        System.out.println("Note: Type your option (1-4). System will auto-submit when time is up.");
        System.out.println("Press ENTER to view questions...");
        scanner.nextLine();

        // FUNCTIONALITY 4: TIMER & AUTO-SUBMIT SETUP
        examTimer = new Timer();
        examTimer.schedule(new TimerTask() {
            int secondsLeft = examDurationSeconds;
            
            @Override
            public void run() {
                if (secondsLeft == 15) {
                    System.out.println("\n\n⚠️ WARNING: Only 15 seconds remaining!");
                }
                if (secondsLeft <= 0) {
                    System.out.println("\n\n⏱️ TIME IS UP! Auto-submitting your answers...");
                    examTimer.cancel();
                    autoSubmitExam();
                }
                secondsLeft--;
            }
        }, 0, 1000);

        // FUNCTIONALITY 3: SELECTING ANSWERS FOR MCQs
        for (int i = 0; i < questions.size(); i++) {
            if (isExamSubmitted) break; // Break out if background thread auto-submitted

            Question q = questions.get(i);
            System.out.println("\nQ" + (i + 1) + ": " + q.questionText);
            for (String option : q.options) {
                System.out.println("   " + option);
            }
            
            System.out.print("Your answer (1-4), or press 0 to skip: ");
            
            // Check if user is typing or if time ran out
            if (!isExamSubmitted) {
                String input = scanner.nextLine();
                try {
                    int ans = Integer.parseInt(input);
                    if (ans >= 0 && ans <= 4) {
                        userAnswers[i] = ans;
                    } else {
                        System.out.println("Invalid option index. Marked as skipped.");
                        userAnswers[i] = 0;
                    }
                } catch (NumberFormatException e) {
                    // Handled if user presses enter directly or gives non-integer input
                    userAnswers[i] = 0; 
                }
            }
        }

        // Manual submit if user finishes before time
        if (!isExamSubmitted) {
            examTimer.cancel();
            calculateAndDisplayResult();
        }
    }

    private static synchronized void autoSubmitExam() {
        if (!isExamSubmitted) {
            isExamSubmitted = true;
            calculateAndDisplayResult();
            System.exit(0);
        }
    }

    private static void calculateAndDisplayResult() {
        isExamSubmitted = true;
        System.out.println("\n=========================================");
        System.out.println("             EXAM RESULT CARD            ");
        System.out.println("=========================================");
        
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            int submittedAns = userAnswers[i];
            
            System.out.print("Q" + (i + 1) + ": ");
            if (submittedAns == 0) {
                System.out.println("Skipped ⚪");
            } else if (submittedAns == q.correctAnswerIndex) {
                System.out.println("Correct ✔");
                score += 10; // 10 points for correct answer
            } else {
                System.out.println("Incorrect ❌ (Correct option was: " + q.correctAnswerIndex + ")");
            }
        }

        System.out.println("\nFinal Score Summary:");
        System.out.println("Total Marks Obtained: " + score + " / " + (questions.size() * 10));
        System.out.println("=========================================");
        
        // Final Cleanup Session Close
        logout();
    }

    private static void logout() {
        System.out.println("\n✔ Session Closing... User successfully logged out.");
        System.out.println("Thank you for using the Online Examination Portal.");
    }
}